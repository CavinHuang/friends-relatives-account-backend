/**
 * 亲友类型
 * @author huangchunmao
 * @email sujinw@qq.com
 * @version v1.0.0
 * @date 2021/1/25
*/

export interface FriendsIndexListsItem {
  letter: string,
  data: Array<any>
}