'use strict';
export default class UserService {
  async getuser(): Promise<object> {
    return {
      a: 1,
    };
  }
}
