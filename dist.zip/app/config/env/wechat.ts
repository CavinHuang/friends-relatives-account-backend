'use strict';
/**
 * 微信相关的配置
 */

export default {
  appId: 'wx123004cdf793dff7',
  appSecret: '9ffb80d80894134154ed6bbfe8fb869e'
}